<?php
include 'dbconnect.php';


if (isset($_GET['id'])) {
    $obatId = $_GET['id'];
} else {
    die(json_encode(["error" => "ID obat tidak ditemukan"]));
}


$sql = "SELECT * FROM obat WHERE id = $obatId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
   
    $obat = $result->fetch_assoc();
    echo json_encode($obat);
} else {
    
    echo json_encode(["error" => "Obat tidak ditemukan"]);
}


$conn->close();
?>