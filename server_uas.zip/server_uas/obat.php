<?php
include_once 'dbconnect.php';

$stat = $conn->prepare("SELECT id, nama_obat, keterangan, harga, gambar FROM obat;");
$stat->execute();
$stat->bind_result($id, $nama_obat, $keterangan, $harga, $gambar);

$arrayproduct = array();

while ($stat->fetch()) {

    $data = array();
    $data['id'] = $id;
    $data['nama_obat'] = $nama_obat;
    $data['keterangan'] = $keterangan;
    $data['harga'] = $harga;
    $data['gambar'] = $gambar;

    array_push($arrayproduct, $data);
}

echo json_encode($arrayproduct);
?>