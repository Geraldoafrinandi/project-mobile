<?php
include_once 'dbconnect.php';

$stat = $conn->prepare("SELECT id, nama_rs, alamat, no_telp, gambar, map FROM rumkit;");
$stat->execute();
$stat->bind_result($id, $nama_rs, $alamat, $no_telp, $gambar, $map);

$arrayproduct = array();

while ($stat->fetch()) {

    $data = array();
    $data['id'] = $id;
    $data['nama_rs'] = $nama_rs;
    $data['alamat'] = $alamat;
    $data['no_telp'] = $no_telp;
    $data['gambar'] = $gambar;
    $data['map'] = $map;

    array_push($arrayproduct, $data);
}

echo json_encode($arrayproduct);
?>