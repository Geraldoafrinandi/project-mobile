<?php
include 'dbconnect.php';

$response = array();

$userId = $_GET['user_id'] ?? $_POST['user_id'] ?? null;

if (!$userId) {
    $response['status'] = 'error';
    $response['message'] = 'User ID tidak ditemukan';
    echo json_encode($response);
    exit;
}

$query_total = mysqli_query($conn, "SELECT SUM(jumlah * harga) as total FROM keranjang WHERE user_id = '$userId'");

if (!$query_total) {
    $response['status'] = 'error';
    $response['message'] = 'Gagal menghitung total harga';

    echo json_encode($response);
    exit;
}

$hasil = mysqli_fetch_array($query_total);

$response['status'] = 'success';
$response['total'] = $hasil['total'] ? $hasil['total'] : '0';

echo json_encode($response);
?>