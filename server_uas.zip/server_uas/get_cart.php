<?php
include 'dbconnect.php';

$response = array();


if (!isset($_POST['user_id'])) {
    echo json_encode(array(
        "status" => "error",
        "message" => "Parameter 'user_id' tidak ditemukan."
    ));
    exit;
}

$userId = $_POST['user_id']; 


if (empty($userId)) {
    echo json_encode(array(
        "status" => "error",
        "message" => "Parameter 'user_id' tidak boleh kosong."
    ));
    exit;
}

$userId = mysqli_real_escape_string($conn, $userId);


$selectKeranjang = mysqli_query($conn, "
    SELECT keranjang.id, keranjang.jumlah, obat.nama_obat, obat.gambar, obat.harga 
    FROM keranjang 
    JOIN obat ON keranjang.produk_id = obat.id 
    WHERE keranjang.user_id = '$userId'
");

if ($selectKeranjang) {
    while ($row = mysqli_fetch_assoc($selectKeranjang)) {
        $key = array();
        $key['id'] = $row['id'];
        $key['jumlah'] = $row['jumlah'];
        $key['nama_obat'] = $row['nama_obat'];
        $key['gambar'] = $row['gambar'];
        $key['harga'] = $row['harga'];

        array_push($response, $key);
    }
    echo json_encode($response);
} else {
    echo json_encode(array(
        "status" => "error",
        "message" => "Gagal mengambil data keranjang. " . mysqli_error($conn)
    ));
}
?>
