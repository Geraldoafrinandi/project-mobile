<?php
include 'dbconnect.php';

$search = $_GET['search'];
$sql = "SELECT * FROM obat WHERE nama_obat LIKE '%$search' OR kategori LIKE '%$search'";

$exe = mysqli_query($conn, $sql);

$response = array();

while ($rows = $exe->fetch_assoc()) {
    $response[] = $rows;
}

echo json_encode($response);
