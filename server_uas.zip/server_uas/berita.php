<?php
include_once 'dbconnect.php';

$stat = $conn->prepare("SELECT id, judul_berita, deskripsi, gambar FROM berita;");
$stat->execute();
$stat->bind_result($id, $judul_berita, $deskripsi, $gambar);

$arrayproduct = array();

while ($stat->fetch()) {

    $data = array();
    $data['id'] = $id;
    $data['judul_berita'] = $judul_berita;
    $data['deskripsi'] = $deskripsi;
    $data['gambar'] = $gambar;

    array_push($arrayproduct, $data);
}

echo json_encode($arrayproduct);
?>