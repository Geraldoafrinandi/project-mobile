<?php
include_once 'dbconnect.php';

$id = isset($_GET['id']) ? $_GET['id'] : 1;


$sql = "SELECT id, nama, alamat FROM pasien WHERE id = $id";

$result = $conn->query($sql);

$data = array();

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data = [
        'id' => $row['id'],
        'nama' => $row['nama'],
        'alamat' => $row['alamat']
    ];
} else {
    $data = ['error' => 'Data tidak ditemukan'];
}

$conn->close();


echo json_encode($data);
?>
