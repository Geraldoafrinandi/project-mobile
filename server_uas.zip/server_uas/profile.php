<?php
include 'dbconnect.php';

$user_id = $_GET['user_id'] ?? $_POST['user_id'] ?? null;

if (!$user_id) {
    echo json_encode(['success' => false, 'message' => 'User ID tidak ditemukan']);
    exit;
}

function getProfile($conn, $user_id)
{
    $sql = "SELECT nama, email, password FROM user WHERE id = $user_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

function getPasien($conn, $user_id)
{
    $sql = "SELECT nama, tgl_lahir FROM pasien WHERE id = $user_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

function updateProfile($conn, $user_id, $nama, $email, $password)
{
    if (empty($nama) || empty($email) || empty($password)) {
        return ['success' => false, 'message' => 'Nama, email, dan password tidak boleh kosong'];
    }

    $sql = "UPDATE user SET nama = '$nama', email = '$email', password = '$password' WHERE id = $user_id";
    if ($conn->query($sql) === TRUE) {
        return ['success' => true, 'message' => 'Profil berhasil diupdate'];
    } else {
        return ['success' => false, 'message' => 'Gagal mengupdate profil'];
    }
}

function updatePasien($conn, $user_id, $nama, $tgl_lahir = null)
{
    if (empty($nama)) {
        return ['success' => false, 'message' => 'Nama pasien tidak boleh kosong'];
    }

    $tgl_lahir = $tgl_lahir !== null ? "'$tgl_lahir'" : "NULL";

    $sql = "UPDATE pasien SET 
            nama = '$nama', 
            tgl_lahir = $tgl_lahir
            WHERE id = $user_id";

    if ($conn->query($sql) === TRUE) {
        return ['success' => true, 'message' => 'Data pasien berhasil diupdate'];
    } else {
        return ['success' => false, 'message' => 'Gagal mengupdate data pasien'];
    }
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $userData = getProfile($conn, $user_id);
    $pasienData = getPasien($conn, $user_id);

    if ($userData === null && $pasienData === null) {
        echo json_encode(['success' => false, 'message' => 'Data tidak ditemukan']);
    } else {
        echo json_encode([
            'success' => true,
            'data' => [
                'user' => $userData,
                'pasien' => $pasienData,
            ],
        ]);
    }
} elseif ($method === 'POST') {
    $nama = $_POST['nama'] ?? null;
    $email = $_POST['email'] ?? null;
    $password = $_POST['password'] ?? null;
    $tgl_lahir = $_POST['tgl_lahir'] ?? null;

    $resultUser = updateProfile($conn, $user_id, $nama, $email, $password);

    $resultPasien = updatePasien($conn, $user_id, $nama, $tgl_lahir);

    if ($resultUser['success'] && $resultPasien['success']) {
        echo json_encode(['success' => true, 'message' => 'Profil user dan pasien berhasil diupdate']);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Gagal mengupdate profil',
            'errors' => [
                'user' => $resultUser['message'],
                'pasien' => $resultPasien['message'],
            ],
        ]);
    }
}

$conn->close();
