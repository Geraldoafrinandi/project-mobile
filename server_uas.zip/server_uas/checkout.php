<?php
include 'dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
    $userId = $_POST['user_id'];  

    $query_cek = mysqli_query($conn, "SELECT * FROM keranjang WHERE user_id = '$userId'");
    $hasil_cek = mysqli_fetch_array($query_cek);

    if ($hasil_cek) {
        $resi = date('YmdHis');

        $tambah_resi = "INSERT INTO pesanan (resi, user_id, order_at, status) VALUES ('$resi','$userId', NOW(), 1)";
        if (mysqli_query($conn, $tambah_resi)) {
            do {
                $produk_id = $hasil_cek['produk_id'];
                $jumlah = $hasil_cek['jumlah'];
                $harga = $hasil_cek['harga'];

                $tambah_detail_order = mysqli_query($conn, "INSERT INTO detail_order (produk_id, jumlah, harga, resi) VALUES ('$produk_id', '$jumlah', '$harga', '$resi')");
            } while ($hasil_cek = mysqli_fetch_array($query_cek));  

            $hapus_keranjang = mysqli_query($conn, "DELETE FROM keranjang WHERE user_id = '$userId'");

            echo json_encode(["status" => "Checkout Berhasil"]);
        } else {
            echo json_encode(["status" => "Checkout Gagal"]);
        }
    } else {
        echo json_encode(["status" => "Produk tidak ditemukan di keranjang"]);
    }
}
?>
