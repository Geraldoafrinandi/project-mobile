<?php
include 'dbconnect.php';


$inputData = json_decode(file_get_contents('php://input'), true);

if ($inputData && isset($inputData['message'])) {
    $userMessage = $inputData['message'];

    
    $sql = "SELECT balasan FROM chat WHERE pesan LIKE '%$userMessage%'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['response' => $row['balasan']]);
    } else {
        echo json_encode(['response' => 'Maaf, saya tidak mengerti.']);
    }

    $conn->close();
} else {
    echo json_encode(['response' => 'Pesan tidak valid.']);
}
