<?php
include 'dbconnect.php';

$nama = $_POST['nama'];
$email = $_POST['email'];
$password = $_POST['password'];
$alamat = $_POST['alamat'];
$jenis_kelamin = $_POST['jenis_kelamin'];

if ($jenis_kelamin !== 'Laki-laki' && $jenis_kelamin !== 'Perempuan') {
    echo json_encode(['pesan' => 'Jenis kelamin tidak valid']);
    exit;
}
$dataUser = mysqli_query($conn, "INSERT INTO user SET nama='$nama', email='$email', password='$password'");
if ($dataUser) {
    $id = mysqli_insert_id($conn);
    $dataPasien = mysqli_query($conn, "INSERT INTO pasien (id, nama, alamat, tgl_lahir, jenis_kelamin) VALUES ('$id', '$nama', '$alamat', NOW(), '$jenis_kelamin')");
    if ($dataPasien) {
        echo json_encode(['pesan' => 'Sukses']);
    } else {
        echo json_encode(['pesan' => 'Gagal menyimpan data pasien']);
    }
} else {
    echo json_encode(['pesan' => 'Gagal menyimpan data pengguna']);
}