<?php
include 'dbconnect.php';  

$pesan = $_POST['pesan'];
$imagePath = '';

if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
    $nama_gambar = $_FILES['gambar']['name'];
    $nama_tmp_gambar = $_FILES['gambar']['tmp_name'];
    $upload_dir = 'uploads/';
    $imagePath = $upload_dir . basename($nama_gambar);

    if (!move_uploaded_file($nama_tmp_gambar, $imagePath)) {
        echo json_encode(['status' => 'error', 'message' => 'Gagal mengupload gambar']);
        exit;
    }
}

if ($imagePath) {
    echo "Path Gambar: " . $imagePath; 
}

$sql = "INSERT INTO pengaduan (pesan, gambar) VALUES ('$pesan', '$imagePath')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['status' => 'success', 'message' => 'Pengaduan berhasil dikirim']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan pengaduan', 'error' => $conn->error]);
}

$conn->close();

