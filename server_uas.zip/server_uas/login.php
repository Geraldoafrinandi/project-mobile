<?php
include 'dbconnect.php';

if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
} else {
    echo json_encode(['error' => 'Email atau password tidak dikirim']);
    exit();
}

$sql = "SELECT * FROM user WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if ($password === $user['password']) {
        echo json_encode([
            "status" => "Login berhasil",
            "user_id" => $user['id'], 
            "email" => $user['email'], 
            "nama" => $user['nama']   
        ]);
    } else {
        echo json_encode(['error' => 'Email atau password salah']);
    }
} else {
    echo json_encode(['error' => 'Email tidak ditemukan']);
}
?>
