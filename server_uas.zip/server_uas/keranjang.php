<?php
include 'dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $response = array();
    $user_id = $_POST['user_id'];
    $produk_id = $_POST['produk_id'];

    $cekKeranjang = mysqli_query($conn, "SELECT * FROM keranjang WHERE user_id= '$user_id' AND produk_id = '$produk_id'");
    $hasilKeranjang = mysqli_fetch_array($cekKeranjang);

    if ($hasilKeranjang) {
        $response['value'] = '2';
        $response['message'] = "Maaf, produk telah tersedia dikeranjang";
        echo json_encode($response);
    } else {
        $cekProduk = mysqli_query($conn, "SELECT * FROM obat WHERE id = '$produk_id'");
        $fetchProduk = mysqli_fetch_array($cekProduk);
        $fetchHarga = $fetchProduk['harga'];

        $tambahKeranjang = "INSERT INTO keranjang (user_id, produk_id, jumlah, harga) VALUES ('$user_id', '$produk_id', 1, '$fetchHarga')";
        
        if (mysqli_query($conn, $tambahKeranjang)) {
            $response['value'] = '1';
            $response['message'] = 'Produk ditambahkan ke keranjang!';
            echo json_encode($response);
        } else {
            $response['value'] = '0';
            $response['message'] = 'Gagal menambahkan ke keranjang';
            echo json_encode($response);
        } 

    }
}
