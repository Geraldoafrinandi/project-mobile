<?php
include 'dbconnect.php';

$response = array();
$user_id = $_GET['user_id'] ?? $_POST['user_id'] ?? null;

$query_select_order = mysqli_query($conn, "SELECT * FROM pesanan WHERE user_id = '$user_id'");

while ($row_order = mysqli_fetch_array($query_select_order)) {

    $key = array();

    $resi = $row_order['resi'];
    $key['resi'] = $resi;
    $key['user_id'] = $row_order['user_id'];
    $key['order_at'] = $row_order['order_at'];
    $key['status'] = $row_order['status'];
    $key['detail'] = array();


    $query_select_order_detail = mysqli_query($conn, "
        SELECT detail_order.*, obat.nama_obat , obat.gambar
        FROM detail_order 
        JOIN obat ON detail_order.produk_id = obat.id 
        WHERE detail_order.resi = '$resi'
    ");

    while ($row_order_detail = mysqli_fetch_array($query_select_order_detail)) {
        $key['detail'][] = array(
            "id" => $row_order_detail['id'],
            "produk_id" => $row_order_detail['produk_id'],
            "namaProduk" => $row_order_detail['nama_obat'],
            "jumlah" => $row_order_detail['jumlah'],
            "harga" => $row_order_detail['harga'],
            "resi" => $row_order_detail['resi'],
            "gambar" => $row_order_detail['gambar'],
        );
    }


    array_push($response, $key);
}


echo json_encode($response, JSON_PRETTY_PRINT);
